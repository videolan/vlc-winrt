#include "pch.h"
#include <assert.h>
#include <errno.h>
#include <stdio.h>

#include "..\include\winrtsock.h"
#include "..\include\winrtsockEx.h"

using namespace Platform;
using namespace Windows::Networking;
using namespace Windows::Networking::Connectivity;

const char * __stdcall gai_strerrorA(int code)
{
	return NULL;
}
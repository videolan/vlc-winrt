#pragma once
#include "..\..\include\winrtsock.h"

int	__stdcall inet_aton(const char *cp, struct in_addr *addr);
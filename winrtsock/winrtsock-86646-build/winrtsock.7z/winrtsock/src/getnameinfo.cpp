#include "pch.h"
#include <assert.h>
#include <errno.h>
#include <stdio.h>

#include "..\include\winrtsock.h"
#include "..\include\winrtsockEx.h"

using namespace Platform;
using namespace Windows::Networking;
using namespace Windows::Networking::Connectivity;

#define NI_NOFQDN 0x01
#define NI_NUMERICHOST 0x02
#define NI_NAMEREQD 0x04
#define NI_NUMERICSERV 0x08
#define NI_DGRAM 0x10

int __stdcall getnameinfo(const struct sockaddr *sa, int salen, char *host, size_t hostlen, char *serv, size_t servlen, int flags)
{
	bool gethost = host && hostlen;
	bool getserv = serv && servlen;

	if (!sa && salen <= 0)
		return EAI_FAMILY;

	if (!gethost && !getserv && (flags & NI_NAMEREQD))
		return EAI_NONAME;

	assert(sa->sa_family == AF_INET);

	if (gethost) {
		if (flags & NI_NUMERICHOST) {
			const char *addr = (const char*) &((const struct sockaddr_in*)sa)->sin_addr;
			sprintf_s(host, hostlen, "%d.%d.%d.%d", addr[0], addr[1], addr[2], addr[3]);
		} else {
			const char *addr;
			size_t len;
			addr = (const char*) &((const struct sockaddr_in*)sa)->sin_addr;
			len = sizeof(struct in_addr);
			struct hostent *h = gethostbyaddr(addr, len, sa->sa_family);
			if (!h) {
				if (errno == EAI_AGAIN)
					return EAI_AGAIN;
				return EAI_FAIL;
			}

			len = strlen(h->h_name) + 1;
			if (len > hostlen)
				return EAI_BADFLAGS;
			memcpy(host, h->h_name, len);
		}
		host[hostlen - 1] = '\0';
	}

	if (getserv) {
		serv[0] = '\0';
	}

	return 0;
}